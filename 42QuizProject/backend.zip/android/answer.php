<?php
header("Content-type: application/json; charset=utf-8");

require_once "connection.php";

$method = $_SERVER["REQUEST_METHOD"];
if ($method === 'GET') {
    $username = isset($_GET['username']) ? $_GET['username'] : '';
    $sql = "SELECT * from answers a JOIN questions q on a.questionId=q.id where a.username like :username";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':username', $username, PDO::PARAM_STR);
    $stmt->execute();


    $answers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $correct = 0;
    $wrong = 0;
    $total = sizeof($answers);
    foreach ($answers as $answer) {
        if ($answer["selected_option"] === $answer["correct_option"])
            $correct++;
        else $wrong++;
    }
    $result = [
        "correct" => $correct,
        "wrong" => $wrong,
        "total" => $total

    ];
    echo json_encode($result);
} else if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    $sql = "insert into answers(questionId,selected_option,username) values (:questionId,:op,:username)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':questionId', $data['questionId']);
    $stmt->bindParam(':op', $data['selected_option']);
    $stmt->bindParam(':username', $data['username']);
    $stmt->execute();
    http_response_code(201);
    echo json_encode(["message" => "Answer added"]);

} else {
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
}