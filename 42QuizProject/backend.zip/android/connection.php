<?php
$host="localhost";
$port=3306;
$dbName="android";
$user="root";
$password="";

try {
    $pdo = new PDO("mysql:host=$host;port=$port;dbname=$dbName;charset=utf8", $user, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch (PDOException $e){
    http_response_code(500);
    echo json_encode(["error"=>"Connection error: ".$e->getMessage()]);
    exit;
}
