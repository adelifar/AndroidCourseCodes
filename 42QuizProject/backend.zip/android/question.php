<?php
header("Content-type: application/json; charset=utf-8");
require_once "connection.php";

$method = $_SERVER["REQUEST_METHOD"];
if ($method === "GET") {
    $statement = $pdo->query("select * from questions");
    $questions = $statement->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($questions);
} else if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    //validation here

    $sql = "INSERT INTO questions (question,option1,option2,option3,option4,correct_option) VALUES (:question,:option1,:option2,:option3,:option4,:correct_option)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':question', $data["question"]);
    $stmt->bindParam(':option1', $data["option1"]);
    $stmt->bindParam(':option2', $data["option2"]);
    $stmt->bindParam(':option3', $data["option3"]);
    $stmt->bindParam(':option4', $data["option4"]);
    $stmt->bindParam(':correct_option', $data["correct_option"]);
    $stmt->execute();
    http_response_code(201);
    echo json_encode(["message" => "Question added successfully"]);

} else {
    var_dump($method);
    http_response_code(405);
    echo json_encode(["error" => "Method not allowed"]);
}
